#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QThread>
#include <QMenu>
#include <QSystemTrayIcon>
#include "Bot/telegrammbot.h"


QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT
    TelegrammBot *m_bot;
    QThread *m_botThread;
    bool m_botIsRunning = false;
    bool m_botIsCreated = false;

    QSystemTrayIcon *m_trayIcon;
    QMenu *m_trayIconMenu;

    //settings:
    QString m_token;
    QString m_dbHash;
    QString m_excelFilePath;
    bool m_hideWindow;
    int m_lastUpdateId;
public:
    Widget(QWidget *parent = nullptr);
    bool isHideWgt() {return m_hideWindow;};
    void startBotHided();
    ~Widget();

signals:
    void deleteBot();
    void startBot();

private slots:
    void prepareAndStartBot();
    void stopBot();
    void botError(QString description, int errCode = 0);
    void on_pB_changeToken_clicked();
    void on_pB_changeDB_clicked();

private:
    Ui::Widget *ui;
    void changeEvent(QEvent*);
    void prepareTray();
    void loadSettings();
    bool checkState();
    void saveSettings();
    void indexDataBase();
    void indexer();
    QString getHash(QString fname);
    bool isDataBaseDiffer(QString fname = QString());
    void loadNewDataBase(QString fname = QString());
};
#endif // WIDGET_H
