#ifndef TELEGRAMMBOT_H
#define TELEGRAMMBOT_H

#include <QObject>
#include <QNetworkRequest>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonObject>
#include <QAxObject>

class TelegrammBot : public QObject
{
    Q_OBJECT
    QString m_token;
    QString m_updateMsgsUrl  = "https://api.telegram.org/bot%1/getUpdates?offset=%2";
    QString m_sendMessageUrl = "https://api.telegram.org/bot%1/sendMessage?parse_mode=HTML&chat_id=%2&reply_to_message_id=%3&text=%4";
    QString m_deleteMessageUrl = "%1";

    QNetworkAccessManager *m_networkManager; // Менеджер по запросам к сети
    QSslConfiguration m_sSlConfig; // SSL настройки
    QNetworkRequest m_updateMsgRequest; // Запрос на получение сообщений
    QNetworkRequest m_sendMessageRequest; // Запрос на отправку сообщений
    QNetworkRequest m_deleteMessageRequest; // Запрос на удаление сообщений

    int m_lastUpdatedId;
    QJsonObject m_indexedINNs;
    QString m_excelFilePath;

    QAxObject *m_excel = nullptr;
    QAxObject *m_workbook = nullptr;

    bool m_isValid = true;
    bool m_isPrepared = false;

public:
    explicit TelegrammBot(QString token, QJsonObject indexedINNs,
                          int lastUpdateId = 0, QObject *parent = nullptr);
    ~TelegrammBot();

signals:
    void botStarted();
    void botError(QString error, int code = 0);
    void botLog(QString log);

public slots:
    void getNewMessages();
    bool isValid(){return m_isValid;}


private:
    bool prepareNework();
    bool prepareExcel();
    void prepareAnswer(QJsonObject &messageObj);
    void sendOrganizationInfo(int chatID, int messageId, QString INN);
    void processWitchCommand(int chatId, int messageId, QString messageText, QJsonObject &messageObj);
    void sendSimpleMessage(QString chatId, QString reply_to_message_id, QString message);

private slots:
    void parseMessages(QNetworkReply *reply);

signals:
    void readyToGetNewMessages();

};

#endif // TELEGRAMMBOT_H
