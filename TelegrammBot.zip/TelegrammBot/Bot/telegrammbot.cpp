#include "telegrammbot.h"
#include <QDebug>
#include <QJsonDocument>
#include <QJsonArray>
#include <QRegExpValidator>
#include <QDir>
#include <QThread>
#include "qt_windows.h"

TelegrammBot::TelegrammBot(QString token, QJsonObject indexedINNs,
                           int lastUpdateId, QObject *parent) :
    QObject(parent),
    m_token(token),
    m_lastUpdatedId(lastUpdateId),
    m_indexedINNs(indexedINNs)
{

}

TelegrammBot::~TelegrammBot()
{
    if (m_workbook) {
        if (!m_workbook->isNull())
            m_workbook->dynamicCall("Close()");
        delete m_workbook;
    }

    if (m_excel) {
        if (!m_excel->isNull())
            m_excel->dynamicCall("Quit()");
        delete m_excel;
    }

    QFile file("lastUpdate");
    file.open(QFile::OpenModeFlag::WriteOnly);
    file.write(QString::number(m_lastUpdatedId).toStdString().data());
    file.close();

    qDebug() << "~TelegrammBot()";
    thread()->quit();
}

bool TelegrammBot::prepareNework()
{
    m_updateMsgsUrl = m_updateMsgsUrl.arg(m_token);
    m_sendMessageUrl = m_sendMessageUrl.arg(m_token);
    m_deleteMessageUrl = m_deleteMessageUrl.arg(m_token);

    m_networkManager = new QNetworkAccessManager(this);

    m_sSlConfig.setDefaultConfiguration(QSslConfiguration::defaultConfiguration());
    m_sSlConfig.setProtocol(QSsl::TlsV1_2);
    m_updateMsgRequest.setSslConfiguration(m_sSlConfig);
    m_sendMessageRequest.setSslConfiguration(m_sSlConfig);

    connect(m_networkManager, &QNetworkAccessManager::finished,
            this, &TelegrammBot::parseMessages);
    connect(m_networkManager, &QNetworkAccessManager::finished,
            this, &TelegrammBot::getNewMessages);
    return true;
}

bool TelegrammBot::prepareExcel()
{
    QDir dir = QDir::current();
    if (!dir.exists("dataBase.xlsx")) {
        qDebug() << "File not found";
        m_isValid = false;
        return false;
    }

    OleInitialize(0);

    m_excel = new QAxObject("Excel.Application", 0);
    if (m_excel->isNull()) {
        qDebug() << "m_excel->isNull()";
        return false;
    }

    m_workbook = m_excel->querySubObject("Workbooks")
            ->querySubObject("Open(const QString&)", dir.filePath("dataBase.xlsx"));
    if (m_workbook->isNull()) {
        qDebug() << "m_workbook->isNull()";
        return false;
    }

    return true;
}

void TelegrammBot::getNewMessages()
{
    if (!m_isPrepared) {
        m_isValid = prepareExcel();
        m_isValid = prepareNework();
        m_isPrepared = m_isValid;
        if (m_isValid)
            emit botStarted();
        else
            emit botError("Ошибка запуска бота", -1);
    }

    if (!m_isValid)
        deleteLater();

    thread()->msleep(500);

    m_updateMsgRequest.setUrl(QUrl(m_updateMsgsUrl.arg(m_lastUpdatedId)));
    m_networkManager->get(m_updateMsgRequest);
}

void TelegrammBot::parseMessages(QNetworkReply *reply)
{
    auto replyDoc = QJsonDocument::fromJson(reply->readAll());
    QJsonObject replyObj = replyDoc.object();

    if (!replyObj["ok"].toBool()) {
        emit botError(replyObj["description"].toString(),
                replyObj["error_code"].toInt());
        return;
    }

    if (!replyObj.contains("result"))
        return;

    QJsonArray results = replyObj["result"].toArray();
    for (auto result : results) {
        auto resultObj = result.toObject();
        if (resultObj["update_id"].toInt() > m_lastUpdatedId) {
            m_lastUpdatedId = resultObj["update_id"].toInt();
            QJsonObject messageObj = resultObj["message"].toObject();
            if (messageObj["from"].toObject()["is_bot"].toBool())
                continue;
            prepareAnswer(messageObj);
        }
    }
}

void TelegrammBot::prepareAnswer(QJsonObject &messageObj)
{
    QString messageText = messageObj["text"].toString();
    int chatID = messageObj["chat"].toObject()["id"].toInt(-1);
    int messageId = messageObj["message_id"].toInt(-1);

    if (messageText[0] == '/') {
        processWitchCommand(chatID, messageId, messageText, messageObj);
        return;
    }

    int pos = 0;
    QRegExpValidator val(QRegExp("[0-9]\\d{10}"));
    if (val.validate(messageText, pos)) {
        sendSimpleMessage(QString::number(chatID), QString::number(messageId),
                          "Принял, ищу ИНН в базе данных...");
        sendOrganizationInfo(chatID, messageId, messageText);
    } else {
        sendSimpleMessage(QString::number(chatID), QString::number(messageId),
                          "Введеное значение не соответствует формату ИНН номера");
    }
}

void TelegrammBot::sendOrganizationInfo(int chatID, int messageId, QString INN)
{
    if (!m_indexedINNs.contains(INN)) {
        sendSimpleMessage(QString::number(chatID), QString::number(messageId),
                          "Информация по заданному ИНН отсутствует в базе данных.");
        return;
    }

    QStringList stringList;
    int row = m_indexedINNs.value(INN).toInt();

    QAxObject* sheet = m_workbook->querySubObject("Worksheets")
            ->querySubObject("Item(int)", 1);

    QAxObject* rows = sheet->querySubObject("Rows");
    QAxObject* headerRow = rows->querySubObject("Item(int)", 1)
            ->querySubObject("Columns");
    QAxObject* contentRow = rows->querySubObject("Item(int)", row)
            ->querySubObject("Columns");

    QAxObject* columns = sheet->querySubObject("UsedRange")
            ->querySubObject("Columns");
    int countCols = columns->property("Count").toInt();

    qDebug() << "information finded" << countCols;

    for (int i = 1; i <= countCols; ++i){
        QAxObject* headerCell = headerRow->querySubObject("Item(int)", i);
        QAxObject* contentCell = contentRow->querySubObject("Item(int)", i);

        auto headerValue = headerCell->property("Text").toString();
        auto contentValue = contentCell->property("Text").toString();

        contentValue.remove('#');

//        qDebug() << headerValue << contentValue;
        if (contentValue.size())
            stringList << "<b>" + headerValue + "</b>: " + contentValue + "\n";
    }

    if (!stringList.size()) {
        sendSimpleMessage(QString::number(chatID), QString::number(messageId),
                          "Информация по заданному ИНН отсутствует в базе данных.");
    }

    QString message;
    for (auto &string : stringList) {
        if (message.size() + string.size() >= 4096) {
            sendSimpleMessage(QString::number(chatID), QString::number(messageId), message);
//            qDebug() << message.toStdString().data();
            message.clear();
        }
        message += string;
    }

    if (message.size())
        sendSimpleMessage(QString::number(chatID), QString::number(messageId), message);
}

void TelegrammBot::processWitchCommand(int chatID, int messageId, QString messageText, QJsonObject &messageObj)
{
    if (messageText == "/start") {
        QString userName = messageObj["from"].toObject()["username"].toString("No user name");
        QString answerText = "Здравствуй, %1!\nОтправь мне ИНН, и я поищу его в своей базе данных";
        sendSimpleMessage(QString::number(chatID), QString::number(messageId),
                          answerText.arg(userName));
    }
}

void TelegrammBot::sendSimpleMessage(QString chatId, QString reply_to_message_id, QString message)
{
    m_sendMessageRequest.setUrl(QUrl(m_sendMessageUrl.arg(chatId).arg(reply_to_message_id).arg(message)));
    m_networkManager->get(m_sendMessageRequest);
}


