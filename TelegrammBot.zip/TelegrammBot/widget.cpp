#include "widget.h"
#include "ui_widget.h"

#include <QDebug>
#include <QJsonObject>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>
#include <QJsonDocument>
#include <QAction>
#include <QIcon>
#include <QLabel>
#include <QCryptographicHash>

#include "qt_windows.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    loadSettings();

    connect(ui->pB_startBot, &QPushButton::clicked,
            this, &Widget::prepareAndStartBot);
    connect(ui->pB_stopBot, &QPushButton::clicked,
            this, &Widget::stopBot);
    connect(ui->pB_hideWgt, &QPushButton::clicked,
            this, &Widget::hide);
    connect(ui->cB_hideWgt, &QCheckBox::toggled,
            this, [this](bool state){m_hideWindow = state;});
    prepareTray();
}

void Widget::startBotHided()
{
    if (checkState())
        prepareAndStartBot();
    else
        show();

}

void Widget::prepareTray()
{
    m_trayIconMenu = new QMenu(this);

    QAction *showWgt = new QAction("Показать окно", m_trayIconMenu);
    connect(showWgt, &QAction::triggered,
            this, &Widget::show);
    m_trayIconMenu->addAction(showWgt);

    QAction *hideWgt = new QAction("Скрыть окно", m_trayIconMenu);
    connect(hideWgt, &QAction::triggered,
            this, &Widget::hide);
    m_trayIconMenu->addAction(hideWgt);

    QAction *quit = new QAction("Завершить работу", m_trayIconMenu);
    connect(quit, &QAction::triggered,
            this, &Widget::deleteLater);
    m_trayIconMenu->addAction(quit);

    m_trayIcon = new QSystemTrayIcon(this);
    m_trayIcon->setContextMenu(m_trayIconMenu);
    QPixmap pix(":/icons/telegram-icon.png");
    QIcon trayImage(pix.scaled(16,16));
    m_trayIcon->setIcon(trayImage);
    m_trayIcon->show();
}

Widget::~Widget()
{
    if (m_botIsRunning) {
        emit deleteBot();
        m_botThread->wait();
        m_botThread->terminate();
    }
    saveSettings();
    m_trayIcon->hide();
    delete m_trayIcon;
    delete ui;
    qDebug() << "~Widget()";
    exit(0);
}

void Widget::prepareAndStartBot()
{
    QFile indexes("indexes.bin");
    if (!indexes.exists())
        indexDataBase();

    indexes.open(QFile::ReadOnly);
    QJsonDocument doc = QJsonDocument::fromBinaryData(indexes.readAll());

    m_bot = new TelegrammBot(m_token, doc.object(), m_lastUpdateId);

    connect(this, &Widget::startBot,
            m_bot, &TelegrammBot::getNewMessages);
    connect(this, &Widget::deleteBot,
            m_bot, &TelegrammBot::deleteLater);

    connect(m_bot, &TelegrammBot::botError,
            this, &Widget::botError);

    m_botThread = new QThread(this);

    connect(m_bot, &TelegrammBot::destroyed,
            m_botThread, &QThread::quit);

    connect(m_botThread, &QThread::finished,
            m_botThread, &QThread::deleteLater);

    connect(m_botThread, &QThread::started,
            this, [this](){
        m_botIsCreated = true;
        ui->pB_startBot->setEnabled(false);
        ui->label_botStatus->setText("Бот запускается");
        m_trayIcon->setToolTip("Бот запускается");
    });

    connect(m_bot, &TelegrammBot::botStarted,
            this, [this](){
        m_botIsRunning = true;
        ui->pB_stopBot->setEnabled(true);
        ui->pB_startBot->setEnabled(false);
        ui->label_botStatus->setText("Бот заущен");
        m_trayIcon->setToolTip("Бот работает");
        m_trayIcon->showMessage("TelegrammBot",
                                "Бот успешно запущен");
    });

    connect(m_botThread, &QThread::destroyed,
            this, [this](){
        m_bot = nullptr;
        m_botIsRunning = false;
        ui->pB_stopBot->setEnabled(false);
        ui->pB_startBot->setEnabled(true);
        ui->label_botStatus->setText("Бот останвлен");
        m_trayIcon->setToolTip("Бот останвлен");
        m_trayIcon->showMessage("TelegrammBot",
                                "Бот успешно остановлен");
    });

    m_bot->moveToThread(m_botThread);
    m_botThread->start();
    emit startBot();
}

void Widget::stopBot()
{
    if (m_botIsRunning)
        emit deleteBot();
}

void Widget::botError(QString description, int errCode)
{
    switch (errCode) {
    case -1:
        m_trayIcon->showMessage("TelegrammBot Error",
                                description,
                                QSystemTrayIcon::Critical);
        break;
    case 401:
        m_trayIcon->showMessage("Ошибка авторизации бота",
                                "Проверте правильность токена",
                                QSystemTrayIcon::Critical);
        stopBot();
        break;
    default:
        m_trayIcon->showMessage("TelegrammBot Error [" + QString::number(errCode) + "]",
                                description,
                                QSystemTrayIcon::Critical);
        stopBot();
        break;
    }
}

void Widget::on_pB_changeToken_clicked()
{
    if (m_botIsRunning) {
        auto ans = QMessageBox::information(this, "Внимание",
                                            "Изменение токена приведет к остановке бота."
                                        "Продолжить?",
                                            "Продолжить", "Отмена");
        if (!ans)
            stopBot();
        else
            return;
    }
    thread()->msleep(500);
    m_token = ui->lE_token->text();
    checkState();
}

void Widget::changeEvent(QEvent *event)
{
    QWidget::changeEvent(event);
    if (event -> type() == QEvent::WindowStateChange)
        if (isMinimized())
            this -> hide();
}

void Widget::loadSettings()
{
    QFile settingsFile("settings.json");
    settingsFile.open(QFile::ReadOnly);
    auto data = settingsFile.readAll();
    settingsFile.close();

    QJsonObject settings(QJsonDocument::fromJson(data).object());

    m_token = settings["token"].toString();
    m_excelFilePath = settings["dataBaseFile"].toString();
    m_hideWindow = settings["hideMode"].toBool();
    m_lastUpdateId = settings["lastUpdatedId"].toInt();
    m_dbHash = settings["hash"].toString();

    ui->lE_excelPah->setText(m_excelFilePath);
    ui->lE_token->setText(m_token);
    ui->cB_hideWgt->setChecked(m_hideWindow);

    if (!checkState())
        return;

    if (!isDataBaseDiffer(m_excelFilePath))
        return;

    auto answ = QMessageBox::question(this, "",
                                     "Файл базы данных изменился, провети переиндексацию?",
                                     "Да", "Нет");
    if (!answ)
        loadNewDataBase();

}

bool Widget::checkState()
{
    ui->pB_startBot->setEnabled(false);
    if (m_token.size() == 0)
        return false;
    if (m_excelFilePath.size() == 0)
        return false;
    if (!QFile::exists("dataBase.xlsx")) {
        ui->lE_excelPah->clear();
        m_excelFilePath.clear();
        return false;
    }
    ui->pB_startBot->setEnabled(true);
    return true;
}

void Widget::saveSettings()
{
    QFile file("lastUpdate");
    if(file.open(QFile::OpenModeFlag::ReadOnly)) {
        auto data = file.readAll();
        file.close();
        file.remove();
        m_lastUpdateId = QString(data).toInt();
    }

    QJsonObject settings;
    settings["token"] = m_token;
    settings["dataBaseFile"] = m_excelFilePath;
    settings["hideMode"] = m_hideWindow;
    settings["lastUpdatedId"] = m_lastUpdateId;
    settings["hash"] = m_dbHash;

    QFile file1;
    QJsonDocument doc(settings);
    file1.setFileName("settings.json");
    file1.open(QFile::WriteOnly);
    file1.write(doc.toJson());
    file1.close();
}

void Widget::indexDataBase()
{
    QMessageBox::information(this, "Внимание",
                             "Сейчас будет произведена индексация базы данных "
                             "Индексация может занять продолжительное время, "
                             "а программа зависнет, ожидайте\n\n"
                             "Нажмите \"Ок\" чтобы начать индексацию");
    indexer();

    QMessageBox::information(this, "Внимание",
                             "Индексация базы данных успешно произведена");
}

void Widget::indexer()
{
    QDir dir = QDir::current();
    if (!dir.exists("dataBase.xlsx"))
        return;

    QAxObject* excel = new QAxObject("Excel.Application", 0);
    QAxObject* workbooks = excel->querySubObject("Workbooks");
    QAxObject* workbook = workbooks->querySubObject("Open(const QString&)", dir.filePath("dataBase.xlsx"));
    QAxObject* sheets = workbook->querySubObject("Worksheets");
    QAxObject* sheet = sheets->querySubObject("Item(int)", 1);
    QAxObject* usedRangeRows = sheet->querySubObject("UsedRange");
    QAxObject* rows = usedRangeRows->querySubObject("Rows");
    int countRows = rows->property("Count").toInt();
    QJsonObject indexObj;

    for (int i = 2; i <= countRows; ++i){
        QAxObject* cell = sheet->querySubObject("Cells(int,int)", i, 16);
        QVariant value = cell->property("Value");
        indexObj[value.toString()] = i;
        delete cell;
    }

    QJsonDocument doc(indexObj);
    QFile file("indexes.bin");
    file.open(QFile::WriteOnly);
    file.write(doc.toBinaryData());
    file.close();

    workbook->dynamicCall("Close()");
    excel->dynamicCall("Quit()");

    delete rows;
    delete usedRangeRows;
    delete sheet;
    delete sheets;
    delete workbook;
    delete workbooks;
    delete excel;
}

QString Widget::getHash(QString fname)
{
    QByteArray data;
    QFile newFile(fname);
    if (!newFile.exists())
        return QByteArray("random");
    if (!newFile.open(QFile::ReadOnly)) {
        QMessageBox::critical(this, "Ошибка",
                              QString("Невозможно открыть файл \"%1\"")
                              .arg(fname));
        return QByteArray();
    }
    data = newFile.readAll();
    newFile.close();
    return QCryptographicHash::hash(data, QCryptographicHash::Algorithm::Md5).toHex();
}

bool Widget::isDataBaseDiffer(QString fname)
{
    if (fname.size() == 0)
        fname = m_excelFilePath;

    auto newFileHash = getHash(fname);

    QString oldFileHash;
    if (m_dbHash.size())
        oldFileHash = m_dbHash;
    else
        oldFileHash = getHash("dataBase.xlsx");

    return !(oldFileHash == newFileHash);
}

void Widget::loadNewDataBase(QString fname)
{
    if (fname.size() == 0)
        fname = m_excelFilePath;

    if (QFile::exists("dataBase.xlsx")) {
        if (!QFile::remove("dataBase.xlsx")) {
            QMessageBox::critical(this, "Ошибка",
                                  "Ошибка при удалении старой базы данных");
            return;
        }
    }

    if (!QFile::copy(fname, "dataBase.xlsx")) {
        QMessageBox::critical(this, "Ошибка",
                              "Ошибка при копировании новой базы данных");
        return;
    }
    m_excelFilePath = fname;
    m_dbHash = getHash(m_excelFilePath);
    indexDataBase();
}

void Widget::on_pB_changeDB_clicked()
{
    if (m_botIsRunning) {
        auto ans = QMessageBox::information(this, "Внимание",
                                            "Изменение файла БД приведет к остановке бота."
                                            "Продолжить?",
                                            "Продолжить", "Отмена");
        if (!ans) {
            stopBot();
            thread()->msleep(500);
        } else
            return;
    }
    ui->lE_excelPah->clear();

    QString fname = QFileDialog::getOpenFileName(this, "Выберите файл",
                                                 "",
                                                 "Excel (*.xlsx *.xls)");

    if (!fname.size()) {
        QMessageBox::critical(this, "Ошибка",
                              "Вы не выбрали файл");
        return;
    }

    if(!isDataBaseDiffer(fname))
        return;

    loadNewDataBase(fname);

    ui->lE_excelPah->setText(fname);
    checkState();
}

